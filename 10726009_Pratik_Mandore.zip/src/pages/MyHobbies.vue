<template>
    <q-parallax
        src="~assets\am.webp">
    <h5> <b> Hobbies </b> </h5>
    <h6>
     Dancing <br>
     Watching Movies <br>
     Playing Cricket <br>
    </h6>
    </q-parallax>
</template>