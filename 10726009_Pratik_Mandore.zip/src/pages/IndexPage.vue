<template>
  
  <q-parallax
      src="~assets/am.webp">
      <q-page class="flex flex-center" style="display=flex;
        flex-direction:column;
        align-items:center;">
        <div class="box">
          <img
          alt="Quasar logo"
          src="~assets/profile_pic.jpg"
          style="width: 200px; height: 200px"
        >
          <h6><b> Name </b>: Pratik Mandore </h6>
          <h6><b> Post </b>: Associate trainee </h6>
        </div>
      </q-page>
  </q-parallax>
  


</template>


<script>
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'IndexPage'
})
</script>

<style>
.box {
  align:center;
}
</style>
