<template>
    <q-parallax
        src="~assets\am.webp">
                <h4>  <b> Educational Details  </b> </h4>
                <h6>
                 <b>School</b> : Ujjwal International School (Jalgaon) <br>
                 <b>Engineering Stream</b> : Computer Science <br>
                 <b>College</b> : International Institute of Information and Technology(I2IT),Pune <br>
                 </h6>
                
    </q-parallax>
</template>
