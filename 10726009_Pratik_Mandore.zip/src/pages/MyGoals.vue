<template>
    <q-parallax
        src="~assets\am.webp">
    <h5> <b> Goals </b> </h5>
    <h6> To buy a house </h6>
    </q-parallax>
</template>