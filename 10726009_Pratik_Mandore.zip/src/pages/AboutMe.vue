<template>
    <q-parallax
        src="~assets/am.webp">
        <h4> <b> About Me </b> </h4>
        <h6>  <b> Name </b> : Pratik Mandore <br>
            <b> Date of Birth </b> : 2nd June,2001 <br>
            <b> Native </b> : Jalgaon (Maharashtra)
        </h6>
    </q-parallax>
    
</template>
