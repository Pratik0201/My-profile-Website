<template>
    <q-parallax
        src="~assets\am.webp">
    <h5><b> Technical Skills : </b> </h5>
    <h6> 
     Spring Boot <br>
     Python <br>
     Docker-Kubernetes <br>
     AI-ML <br>
    </h6>
</q-parallax>
</template>